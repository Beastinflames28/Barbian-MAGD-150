let vid;
function setup() {
  noCanvas();
  background(200);
  vid1 = createVideo(['videos/vid1.mp4']);
  vid2 = createVideo(['videos/vid2.ogv']);
  vid3 = createVideo(['videos/vid3.webm']);
  vid1.size(300, 300);
  vid2.size(300, 300);
  vid3.size(300, 300);
  vid1.volume(0.1);
  vid2.volume(0.1);
  vid3.volume(0.1);
  
  vid1.play();
  vid2.play();
  vid3.play();
}




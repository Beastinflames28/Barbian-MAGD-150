let img1;
let img2;
let tranImg;
function preload(){
  img1 = loadImage("images/cat.jpg");
  img2 = loadImage("images/dog.jpg");
  tranImg = loadImage("images/bunny.png");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  let s = "White Bunny"
  background(220);
  textSize(32);
  fill(60);
  strokeWeight(10);
  textFont("Helvetica");
  text("Cat", mouseX, 225);
  textFont("TimesNewRoman");
  text(s, 250, mouseY - 150, 150, 100)
  image(img1, mouseX -100, 0);
  image(img2, 0, 250);
  image(tranImg, 200, mouseY - 100);
  
  
}
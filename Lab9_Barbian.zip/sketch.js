let song;
let capture;
let val1 = 0;
let osc, freq1, amp1;
let playing = false;
function preload() {
  soundFormats('mp3', 'ogg');
  song = loadSound('songs/pizza.mp3');
}
function setup() {
  createCanvas(400, 400);
  osc = new p5.Oscillator('sine');
  capture = createCapture(VIDEO);
  capture.hide();
}

function draw() {
  background(220);
  colorMode(RGB);
  image(capture, 0, 100, width, width * capture.height / capture.width);
  filter(GRAY);
  text("Play", 51, 90);
  text("Stop", 101, 90 );
  text("Oscillator", 142, 90);
  push()
  fill(0, 255, 0);
  square(50, 50, 25)
  pop()
  push()
  fill(255, 0, 0);
  square(100, 50, 25);
  pop();
  square(150, 50, 25);
  freq1 = mouseX;
  amp1 = mouseY;
  if(playing === true){
    osc.freq(freq1, 0.1);
    osc.amp(amp1, 0.1);
    circle(freq1, amp1, 25);
  }
}

function mouseClicked(){
  print(mouseX, mouseY);
    if((mouseX > 50) && (mouseX < 75) && (mouseY>50) && (mouseY <75) && (val1 > 0))  {
  
  }
  else if((mouseX > 50) && (mouseX < 75) && (mouseY>50) && (mouseY < 75))  {
    song.loop();
    val1 ++ ;
  }
else if((mouseX > 100) && (mouseX < 125) && (mouseY>50) && (mouseY <75))  {
     song.stop();
    val1 = 0;
  }
  else if((mouseX > 150) && (mouseX< 175) && (mouseY > 50) && (mouseY < 75) && (playing === false)){
    osc.start();
    playing = true;
  }
    else if((mouseX > 150) && (mouseX< 175) && (mouseY > 50) && (mouseY < 75) && (playing === true)){
    osc.stop();
    playing = false;
  }
}

